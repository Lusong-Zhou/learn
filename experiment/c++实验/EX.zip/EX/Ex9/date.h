extern const int month_day[13]={0,31,28,31,30,31,30, 31,31,30,31,30,31 };
class Data
{
	int year,month,day;
	//2 

};