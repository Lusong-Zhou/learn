#include <iostream.h>
#include "shap.h"
void main()
{

	Point *p=new Point[2];
	p[0]=Point(10,20);
	p->Print();
	delete [] p;




	

/*	p1.Print();
	p2.Print();

	Circle c1(5,6,4.5);//,c2(p1,5);
	cout<<"c1 center:";c1.Print();
	cout<<"c1 area:";	cout<<c1.Area()<<endl;
	*/

}