//#include "shap.h"
class application
{
public:
	void Run(Shap &p)
	{
		cout<<p.Area()<<endl;

	}
};